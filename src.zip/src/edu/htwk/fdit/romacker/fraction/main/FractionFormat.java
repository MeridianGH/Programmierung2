package edu.htwk.fdit.romacker.fraction.main;

public enum FractionFormat {
    AS_WHOLE_NUMBER, AS_FRACTION
}
